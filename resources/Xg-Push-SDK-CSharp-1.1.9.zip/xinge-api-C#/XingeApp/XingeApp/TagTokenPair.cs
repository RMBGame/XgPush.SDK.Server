﻿using System;

namespace XingeApp
{
    public class TagTokenPair
    {
        public TagTokenPair(string tag, string token)
        {
            this.tag = tag;
            this.token = token;
        }

        public string tag;
        public string token;
    }
}
