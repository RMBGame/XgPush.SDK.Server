﻿using System;
using XingeApp;
using Newtonsoft.Json.Linq;

namespace PushTest
{
    class SimpleDemo
    {
        static void Main(string[] args)
        {
            //ANDROID版
            Console.WriteLine(XingeApp.XingeApp.pushTokenAndroid(2100240957, "f255184d160bad51b88c31627bbd9530", "title", "android来自C# SDK的单个设备推测试消息", "76501cd0277cdcef4d8499784a819d4772e0fdde"));
            //Console.WriteLine(XingeApp.XingeApp.pushAccountAndroid(0, "secretKey", "title", "android来自C# SDK的账号推送测试消息", "account"));
            //Console.WriteLine(XingeApp.XingeApp.pushAllAndroid(2100240957, "secretKey", "title", "android来自C# SDK的全量推送测试消息"));
            //Console.WriteLine(XingeApp.XingeApp.pushTagAndroid(2100240957, "secretKey", "title", "android来自C# SDK的标签推送测试消息", "tag"));

            //IOS版
            //Console.WriteLine(XingeApp.XingeApp.pushTokenIos(2200262402, "secretKey", "ios来自C# SDK的单个设备推送测试消息", "token",XingeApp.XingeApp.IOSENV_DEV));
            //Console.WriteLine(XingeApp.XingeApp.pushAccountIos(2200262402, "secretKey", "ios来自C# SDK的账号推送测试消息", "account", XingeApp.XingeApp.IOSENV_DEV));
            //Console.WriteLine(XingeApp.XingeApp.pushAllIos(2200262402, "secretKey", "ios来自C# SDK的全量测试消息", XingeApp.XingeApp.IOSENV_DEV));
            //Console.WriteLine(XingeApp.XingeApp.pushTagIos(2200262402, "secretKey", "ios来自C# SDK的标签推送测试消息", "tag", XingeApp.XingeApp.IOSENV_DEV));


            Console.ReadLine();
        }
    }
}
